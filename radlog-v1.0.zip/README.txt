🏥 RadLog - 放射科病人追蹤工具
================================

謝謝購買 RadLog！

📋 快速開始
1. 執行 RadLog.exe
2. 用購買時的 Google 帳號登入
3. 設定你的 Google Sheet ID
4. 按 Ctrl+Shift+R 開始使用！

📁 檔案說明
- RadLog.exe          主程式
- 安裝指南.pdf        詳細中文指南
- Installation_Guide.pdf  英文指南
- LICENSE.txt         授權條款

🆘 需要幫助？
- Email: support@radlog.cyyang.dev
- 安裝指南有完整步驟說明

🚀 開始提升你的工作效率！

---
RadLog v1.0.0
Purchase verification: https://radlog-license.cyyang.workers.dev